France Trip Mobile Site

Upload the contents of this folder to a static hosting service such as Netlify.
The root file is index.html so the published URL opens the app directly.

On iPhone:
1. Open the published URL in Safari
2. Share
3. Add to Home Screen

Important:
- Uploaded PDFs and locally edited data are stored in that browser/site storage.
- Use the same published URL each time.
- Do not clear Safari website data if you want to keep locally stored PDFs and edits.
